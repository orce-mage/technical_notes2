<?php
require_once 'ConvertM1M2TestCase.php';
class FirstTest extends ConvertM1M2TestCase
{
    public function testSetup()
    {
        $this->assertEquals(-1, -1);
    }
}